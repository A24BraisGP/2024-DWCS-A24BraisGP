<div id="header" class="container">

	<div id="logo">
		<h1><a href="#">PHP</a></h1>
		<p>template design by <a href="http://www.freecsstemplates.org">FCT</a></p>
	</div>