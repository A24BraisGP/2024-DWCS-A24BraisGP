<?php 
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
 <link rel="stylesheet" href="style.css">
</head>
<body>
  <?php 
  include 'header.php';
  include 'footer.php';
  ?>

  <div class="logindiv">
    <a href="login_user.php">Login</a>
  </div>
  <div class="creatediv">
    <a href="create_char.php">Create a character</a>
  </div>
  <div class="rolldiv">
    <a href="roll_dice.php">Roll the dice</a>
  </div>



  <div class="logout">
    <a href="logout.php">Logout</a>
  </div>


</body>
</html>