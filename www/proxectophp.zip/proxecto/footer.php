<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <footer>
   <a href="#">About us</a>
   <a href="#">Contact</a>
   <a href="#">Report Bug</a>
  </footer>
  
</body>
</html>